/*
 * demoheap.h
 *
 *  Created on: Sep 27, 2017
 *      Author: tuxtor
 */

#ifndef DEMOHEAP_H_
#define DEMOHEAP_H_

double* child();
void parent();



#endif /* DEMOHEAP_H_ */
