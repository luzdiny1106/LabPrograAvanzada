package org.eclipse.che.examples;

public class HelloWorld {
    public static void main(String... argvs){
        
        SinglyLinkedList lista = new SinglyLinkedList();
        
        lista.addFirst("GUA");
        lista.addLast("MEX");
        lista.addLast("USA");
        lista.addLast("ESP");
        lista.addLast("FRA");
        lista.addLast("ITA");
        lista.addLast("RUS");
        lista.addLast("SUI");
        lista.addLast("CHI");
        lista.addLast("JAP");
        lista.addLast("COL");
        
        System.out.println(lista.first());
        System.out.println(lista.last());
    }
}
