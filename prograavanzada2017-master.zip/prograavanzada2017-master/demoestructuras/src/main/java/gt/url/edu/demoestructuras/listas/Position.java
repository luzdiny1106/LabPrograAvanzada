package gt.url.edu.demoestructuras.listas;

public interface Position<E> {
	
	E getElement() throws IllegalStateException;

}
