/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio5;

/**
 *
 * @author t203
 */
public interface List<E> {
    
    int size();
    
    boolean isEmpty();
    
    E get(int i);
    
    E set(int i, E e);
    
    void add(int i, E e);
    
//    Removes/returns the element at index i, shifting subsequent elements earlier
//    @return Deleted element at index i
    E remove(int i) throws IndexOutOfBoundsException;
}
