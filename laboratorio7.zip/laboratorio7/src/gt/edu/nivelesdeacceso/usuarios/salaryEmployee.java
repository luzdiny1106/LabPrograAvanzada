/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.nivelesdeacceso.usuarios;

/**
 *
 * @author t203
 */
public class salaryEmployee extends employee{
    
    int annualSalary;
    
    @Override
    protected double monthlyPay(){
        return 1000.00;
    }
    @Override
    protected double annualPay(){
        return this.monthlyPay()*12;
    }

    @Override
    protected int hoursPerWeek() {
        return 8;
    }

    @Override
    protected int hourlyWage() {
        return this.hourlyWage()*5;
    }
}
