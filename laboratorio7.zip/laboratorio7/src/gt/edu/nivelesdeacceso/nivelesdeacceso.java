/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.nivelesdeacceso;

import gt.edu.nivelesdeacceso.usuarios.employee;
/**
 *
 * @author t203
 */

/*NotesLuz
1)public
2)protected    **En Java
3)default
4)private
*/

public class nivelesdeacceso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* employee emp = new employee();
        
        emp.name = "Luz";
        emp.setHireYear(2017);*/
       
       //salaryEmployee semp = new salaryEmployee();
       
    }
    
}
