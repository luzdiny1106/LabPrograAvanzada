/*
 * Persona.cpp
 *
 *  Created on: Sep 27, 2017
 *      Author: tuxtor
 */

#include "Persona.h"

Persona::Persona() {
	// TODO Auto-generated constructor stub

}

Persona::~Persona() {
	// TODO Auto-generated destructor stub
}

