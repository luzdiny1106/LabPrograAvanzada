/*
 * funciones.h
 *
 *  Created on: Sep 18, 2017
 *      Author: tuxtor
 */

#ifndef FUNCIONES_H_
#define FUNCIONES_H_

void demostrarPuntero();
void intercambia(int *, int *);



#endif /* FUNCIONES_H_ */
