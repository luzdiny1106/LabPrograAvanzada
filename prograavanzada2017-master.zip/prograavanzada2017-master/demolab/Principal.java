public class Principal{
	
	public static void main(String args[]){
	
		Automovil ferrari = new Automovil();
		ferrari.setMarca("Ferrari");
		ferrari.setAnno(2007);
		System.out.println(ferrari.toString());
	}

}
