// Simple Hello World
 
#include <iostream>

using namespace std; 

void ordenar_numeros(int lon, int arreglo[]){ 
        int temp; 
         for(int m=0;m<lon;m++) 
                for(int l=0;l<lon-1;l++) 
                    if(arreglo[l]>arreglo[l+1]){ // cambia "<" a ">" para cambiar la manera de ordenar
                        temp=arreglo[l]; 
                        arreglo[l]=arreglo[l+1]; 
                        arreglo[l+1]=temp;} 

                 for(int m=0;m<lon;m++) 
                    cout<<arreglo[m]<<endl; 
                        } 

int main()
{
 //Ingresar tamaño de arreglo.
  int n;  
  
  cout << "Ingrese el numero del tamaño del arreglo: " << endl;
  cin >> n;
  int arreglo[n];
 
 //Ingresar valores en arreglo.
  cout << "Ingrese números enteros: " << endl;
  for(int i = 0; i < n; i++){
        cout << "Valor #" << i + 1 << endl;;
    	cin >> arreglo[i];
    }
 //Sumar todos ost
  int suma = 0;
  for (int j = 0; j < n; j++){
      
      suma += arreglo[j];
  }
  cout << "Suma: " << suma << endl;
  
  cout << "Longitud de Arreglo: " << n << endl;
 // Tomé 0 como numero par, de no hacerlo, lo excluiría del if y su valor (h[0]) 
  int x = 0;
  int y = 0;
  int even[n], odd[n];
  for (int h = 0; h < n; h++){
      if (arreglo[h] % 2 == 0)
      {
          even[x] = arreglo[h];
          x++;
          //x += arreglo[i]; // Suma de posiciones pares.
      }
      else{
          odd[y] = arreglo[h];
          y++;
          //y += arreglo[i]; // Suma de posiciones impares.
      }
  }
  
  int sumaE = 0;
  int sumaO = 0;
  sumaE += arreglo[n];
  sumaO += arreglo[m];

  cout << "Suma Posiciones Pares: " << sumaE << endl;
  cout << "Suma Posiciones Impares: " << sumaO << endl;
  
  cout<<endl<<"Numeros ordenados: "<<endl; 
 // Llamar el método que ordenará números.
  ordenar_numeros(n,arreglo); 
  
  return 0;
  
}