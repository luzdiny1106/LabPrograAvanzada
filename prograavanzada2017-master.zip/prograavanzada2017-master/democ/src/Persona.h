/*
 * Persona.h
 *
 *  Created on: Sep 27, 2017
 *      Author: tuxtor
 */

#ifndef PERSONA_H_
#define PERSONA_H_

class Persona {
public:
	Persona();
	virtual ~Persona();
};

#endif /* PERSONA_H_ */
