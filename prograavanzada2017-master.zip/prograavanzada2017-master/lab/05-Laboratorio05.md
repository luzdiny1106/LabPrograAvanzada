Laboratorio número 4
====================

Tema
----
Estructuras dinamicas con POO

Objetivo
--------
El objetivo del presente laboratorio es adquirir y comprobar sus conocimientos en las siguientes areas:

1. Manejo de stack y heap utilizando Java
2. Conceptos generales de estructuras dinamicas

Tareas solicitadas
------------------
De acuerdo a las instrucciones proporcionadas por el profesor, se le solicita que elabore las siguientes tareas:

1. Implementar una lista enlazada utilizando Java

Tarea para casa
---------------

* Implementar una lista enlazada utilizando C++

Lab 11:00 am
Tarea Lunes 23:55
