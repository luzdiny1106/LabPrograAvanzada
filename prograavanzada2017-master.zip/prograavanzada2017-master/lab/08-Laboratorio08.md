Laboratorio número 7
====================

Tema
----
Lectura de archivos y creación de graficos

Objetivo
--------
El objetivo del presente laboratorio es adquirir y comprobar sus conocimientos en las siguientes areas:

1. Lectura y escritura de archivos en Java
2. Creación de archivos en Graphviz

Tareas solicitadas
------------------
Luego de la explicación del instructor realice las siguientes tareas:

1. Escriba una implementación que sea capaz de leer un archivo cualquiera en una ruta arbitraria solicitada via CLI
2. Intente graficar este archivo utilizando Graphviz
3. Al finalizar grabe en el archivo su nombre y número de carnet



Fecha límite
------------
Lab 11:00 am
