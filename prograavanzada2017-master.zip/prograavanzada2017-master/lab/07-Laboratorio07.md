Laboratorio número 6
====================

Tema
----
Modificadores de acceso, clases abstractas e interfaces funcionales

Objetivo
--------
El objetivo del presente laboratorio es adquirir y comprobar sus conocimientos en las siguientes areas:

1. Modificadores de acceso en Java
2. Niveles de acceso en Java
3. Clases abstractas e interfaces funcionales

Tareas solicitadas
------------------
De acuerdo a sus conocimientos adquiridos, escriba un programa que sea capaz de implementar la siguiente estructura con instrucciones del instructor.

![Diagrama](http://sun0.cs.uca.edu/~pyoung/teaching/archive/CSCI3381_Sp12/classNotes/class14/class14_files/image002.gif)

Tarea para casa
---------------
Este laboratorio no tiene tarea


Fecha límite
------------
Lab 11:00 am
