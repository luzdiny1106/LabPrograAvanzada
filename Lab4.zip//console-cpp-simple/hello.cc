// Simple Hello World
 
#include <iostream>
 
using namespace std; 
 
int suma(int a, int b){
    return a+b;
}
int resta(int a, int b){
    return a-b;
}
int multiplicar(int a, int b){
    return a*b;
}
double dividir(double a, double b){
    return a/b;
}
 
void sumapunteros(int, int, int*);
void restapunteros(int, int, int*);
void multiplicarpunteros(int, int, int*);
void dividirpunteros(double, double, double*);
 
int main()
{
  std::cout << "__________________________Calculadora de Operaciones Aritmeticas por Valor_______________________________" << std::endl;
  int resultadoSuma = suma(7,3);
  int resultadoResta = resta(7,3);
  int resultadoMultiplicar = multiplicar(7,3);
  double resultadoDividir = dividir(7,3);
  std::cout << "Suma: " << resultadoSuma <<std::endl;
  std::cout << "Resta: " << resultadoResta <<std::endl;
  std::cout << "Mulitplicación: " << resultadoMultiplicar <<std::endl;
  std::cout << "División: " << resultadoDividir <<std::endl;
  
  std::cout << "________________________Caluladora de Operaciones Aritmeticas por Referencia_____________________________" << std::endl;
   
  int puntero = 1;
  double puntero2 = 1.0;
  
  sumapunteros(8, 2, &puntero);
  std::cout << "Suma: " << puntero << std::endl;
  restapunteros(8,2, &puntero);
  std::cout << "Resta: " << puntero <<std::endl;
  multiplicarpunteros(8,2, &puntero);
  std::cout << "Multiplicación: " << puntero << std::endl;
  dividirpunteros(8,2, &puntero2);
  std::cout << "División: " << puntero2 << std::endl;
  
  int a[11];
  int t;
  int i,result;
  int respuesta=1;
  cout<<"Escribe el numero de la tabla: "<<endl;
  cin>> t;
  for(i=0;i<=10;i++){
      a[11]=t*i;
      cout<<t<<" * "<<i<<" = "<<a[11]<<endl;
      }
  return 0;
 }


void sumapunteros(int a, int b, int* puntero){
    *puntero = a+b;
}
void restapunteros(int a, int b, int* puntero){
    *puntero = a-b;
}
void multiplicarpunteros(int a, int b, int* puntero){
    *puntero = a*b;
}
void dividirpunteros(double a, double b, double* puntero2){
    *puntero2 = a/b;
} 
