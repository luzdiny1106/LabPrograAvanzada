/*
 * demoarreglos.h
 *
 *  Created on: Sep 27, 2017
 *      Author: tuxtor
 */

#ifndef DEMOARREGLOS_H_
#define DEMOARREGLOS_H_

void testArray();

void testArray2();
void testArray3();
void testArray4();
void test5();


#endif /* DEMOARREGLOS_H_ */
