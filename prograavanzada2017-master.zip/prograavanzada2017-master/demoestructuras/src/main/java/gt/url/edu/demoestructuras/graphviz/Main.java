/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.url.edu.demoestructuras.graphviz;

import java.io.IOException;

public class Main {
    
    public static void main (String[] args) throws IOException{
        
        FileLoader fileManager = new FileLoader();
        
        String ruta = "C:\\Users\\t203\\Desktop\\ejemplo.txt";
        
        String textoLeido = fileManager.loadFileWithJava8(ruta);
        
        textoLeido += "Esto es una linea agregada en Java 8.";
        
        fileManager.writeUsingFileWriter(textoLeido, ruta);
    }
    
}
